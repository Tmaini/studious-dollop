
import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk

# Function to open the second window
def open_second_window():
    second_window = tk.Toplevel(root)
    second_window.title("Secondary Window")
    second_window.geometry("400x300")

    # Label and Entry field
    tk.Label(second_window, text="Enter your age:", font=("Arial", 12)).pack(pady=10)
    age_entry = tk.Entry(second_window, width=20)
    age_entry.pack(pady=5)

    # Display an image
    img = Image.open("example_image1.jpg")  # Replace with your image path
    img = img.resize((100, 100))
    photo = ImageTk.PhotoImage(img)
    img_label = tk.Label(second_window, image=photo)
    img_label.image = photo  # Keep a reference to avoid garbage collection
    img_label.pack(pady=5)
    tk.Label(second_window, text="A beautiful example image.", font=("Arial", 10, "italic")).pack()

    # Button to validate input
    def validate_input():
        user_input = age_entry.get().strip()
        if not user_input:
            messagebox.showerror("Validation Error", "The field cannot be empty.")
        elif not user_input.isdigit():
            messagebox.showerror("Validation Error", "Please enter a valid number.")
        else:
            messagebox.showinfo("Validation Success", f"Your age is: {user_input}")

    validate_btn = tk.Button(second_window, text="Validate", command=validate_input, bg="blue", fg="white")
    validate_btn.pack(pady=10)

    # Back button to close second window
    back_btn = tk.Button(second_window, text="Back", command=second_window.destroy, bg="red", fg="white")
    back_btn.pack(pady=10)

# Exit function
def exit_app():
    root.destroy()

# Main application window
root = tk.Tk()
root.title("Main Window")
root.geometry("400x300")

# Labels
tk.Label(root, text="Welcome to the Tkinter App!", font=("Arial", 16)).pack(pady=20)
tk.Label(root, text="This app demonstrates navigation and input validation.", font=("Arial", 12)).pack(pady=10)

# Display an image
img = Image.open("example_image2.jpg")  # Replace with your image path
img = img.resize((100, 100))
photo = ImageTk.PhotoImage(img)
img_label = tk.Label(root, image=photo)
img_label.image = photo
img_label.pack(pady=5)
tk.Label(root, text="Another example image with alternate text.", font=("Arial", 10, "italic")).pack()

# Buttons
open_btn = tk.Button(root, text="Open Second Window", command=open_second_window, bg="green", fg="white")
open_btn.pack(pady=10)

exit_btn = tk.Button(root, text="Exit", command=exit_app, bg="red", fg="white")
exit_btn.pack(pady=10)

# Start the application
root.mainloop()
